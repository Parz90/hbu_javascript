
function sayHello(name) {
  console.log("Hello, I'm " + name);
}

function walk() {
  console.log("I am walking!");
}

function sayHelloStudent(name, subject) {
  console.log("Hello, I'm " + name);
  console.log("I'm studying " + subject + ".");
}

// Person
function john() {
  sayHello('John');
  walk();  
}

// Student 
function janet() {
  sayHelloStudent('Janet', 'Applied Physics');
  walk();
}

john();
janet();

